#!/bin/bash

WEAVIATE_HOST="http://localhost:8080"
OUTPUT_FILE="objects.json"

# Initialize an empty array to store all objects
echo "[]" > $OUTPUT_FILE

# Define the initial page and limit
PAGE=0
LIMIT=100  # Adjust as needed

while true; do
    # Fetch a page of objects
    RESPONSE=$(curl -s -X GET "$WEAVIATE_HOST/v1/objects?limit=$LIMIT&offset=$((PAGE * LIMIT))" -H "accept: application/json")
    OBJECTS=$(echo $RESPONSE | jq '.objects')

    # Check if the response contains objects
    if [ "$(echo $OBJECTS | jq 'length')" -eq "0" ]; then
        break
    fi

    # Append the fetched objects to the output file
    jq -s '.[0] + .[1]' $OUTPUT_FILE <(echo $OBJECTS) > temp.json && mv temp.json $OUTPUT_FILE

    # Increment the page counter
    PAGE=$((PAGE + 1))
done

echo "Backup complete. All objects are saved in $OUTPUT_FILE"
